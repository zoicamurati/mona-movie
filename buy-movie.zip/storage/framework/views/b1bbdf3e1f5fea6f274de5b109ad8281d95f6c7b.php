<?php $__env->startSection('content'); ?>

    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <h1 style="text-align: center; color: #7e0809; text-transform: uppercase"> Welcome <?php echo e(Auth::user()->name); ?></h1>
                </div>

            </div>
        </div>
    </div>
    <footer class="footer">
        <div class="container-fluid">
            <div class="copyright float-right" id="date">
                <p>©<?php echo e(now()->year); ?><a href="https://digitalmoon.al/"> Digital Moon Agency </a> All Rights Reserved. </p>
            </div>
        </div>
    </footer>

    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Admin\Desktop\buy-movie\resources\views/panel/panel.blade.php ENDPATH**/ ?>