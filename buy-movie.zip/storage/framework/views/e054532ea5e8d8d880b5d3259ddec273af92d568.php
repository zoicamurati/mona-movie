<?php $__env->startSection('content'); ?>
    <div class="alert alert payment-msg">
        <?php if(\Session::has('error')): ?>
            <h1 class="" style="margin: 20px"><?php echo e(\Session::get('error')); ?></h1>
            <?php echo e(\Session::forget('error')); ?>

        <?php endif; ?>
        <?php if(\Session::has('success')): ?>
            <h1 class="" style="margin: 20px"><?php echo e(\Session::get('success')); ?></h1>
            <?php echo e(\Session::forget('success')); ?>

        <?php endif; ?>

        <?php if(!empty($response['code'])): ?>
            <h1 class="" style="margin: 20px">
                <?php echo e($response['message']); ?>

            </h1>
        <?php endif; ?>
        
        <p>hahhahah</p>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Admin\Desktop\buy-movie\resources\views/transaction.blade.php ENDPATH**/ ?>